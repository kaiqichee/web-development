function OpenForm(){
    document.getElementById('edit-profile-form').style.display = 'block';
    document.getElementById('cancel-button').style.display = 'block';
}
function CloseForm(){
    document.getElementById('edit-profile-form').style.display = 'none';
    document.getElementById('cancel-button').style.display = 'none';
}

